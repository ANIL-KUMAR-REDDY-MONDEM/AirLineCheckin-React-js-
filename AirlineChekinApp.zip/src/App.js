import React, { Component } from 'react'
import {Route,Switch } from 'react-router'

import  Login from './components/Login'
import  Logout from "./components/Logout";
import Admin from './components/Admin'
import Signup from './components/Signup';
import Dashboard from './components/Dashboard';
import AddPassenger from './components/AddPassenger'
import EditPassenger from './components/EditPassenger';
import AddService from './components/AddService';
import EditService from './components/EditService';
import EditMeals from './components/EditMeals';
import AddMeals from './components/AddMeals'
import Services from './components/Services'
import Flight from './components/Flights'
import UnAuthorised from './components/UnAuthorised'
import GetPasengers from './components/GetPasengers';
import EditFlight from './components/EditFlight'
import PassengersTable from './components/PassengersTable';
//import { ToastContainer } from 'react-toastify';
export default class App extends Component {
  render() {
    return (
      <div className="App">
       
      <Switch>
        <Route exact path="/" component={Dashboard}/>
        <Route exact path="/Login" component={Login} />
        <Route exact path="/Logout" component={Logout}/>
        <Route exact path="/Admin" component={Admin}/>
         <Route exact path="/Signup" component={Signup}/>



         <Route exact path="/AddPassenger" component={AddPassenger}/>
        
         <Route exact path="/editPassenger/:id" component={EditPassenger}/>
       


         <Route exact path="/admin/getpassengers" component={GetPasengers}/>


         <Route exact path="/admin/services" component={Services}/>
      <Route exact path="/admin/services/AddService" component={AddService}/>
      <Route exact path="/admin/services/EditService/:id" component={EditService}/> 
      
      
      <Route exact path="/admin/services/AddMeals" component={AddMeals}/>
      <Route exact path="/admin/services/EditMeals/:id" component={EditMeals}/> 


       
        <Route exact path="/admin/flights" component={Flight}/>
        <Route exact path="/admin/editPassengers/:id" component={PassengersTable}/>
        <Route exact path="/UnAuthorised" component={UnAuthorised}/>
        <Route exact path="/admin/editFlight/:id" component={EditFlight}/>
       
      </Switch>
     
      </div>
    )
  }
}
