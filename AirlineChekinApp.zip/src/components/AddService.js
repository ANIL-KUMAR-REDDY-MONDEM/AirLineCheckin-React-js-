import axios from 'axios'
import React, { useState ,useParams} from 'react'
import { Link, Redirect } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import { useHistory } from 'react-router'
import verifyToken from './VerifyToken'
const AddService =()=>{
    const dispatch=useDispatch();
  //  const {id}=useParams();
   const histroy=useHistory();
   const [service,setService]=useState("")
   const [redirect,setRedirect]=useState(false);
   const addService=(e)=>{
           e.preventDefault();
            axios.post('/services',{service}).then((response)=>{
                      dispatch({type:"ADD_SERVICE",
                        payload:response.data})
                        setRedirect(true);
                      })
    }



    const cancel=()=>{
      
       setRedirect(true);
    }

    if(redirect){
        return (
            <Redirect to="/admin/services"/>
        )
    }
const token=localStorage.getItem('token');
const auth=verifyToken(token)
if(auth==="staff" || auth===false)
{
    return <Redirect to="/UnAuthorised"/>
}
        return (
          
            <div className="container">
                  {redirect? <Redirect to="/admin/services"/>:null}
                <div className="form-group my-5">
                                      <input type="text" 
                                      placeholder="Add Services" 
                                      className="form-control"
                                      value={service}
                                      onChange={e=>setService(e.target.value)}/>
                                  </div>
                                  <button onClick={addService} type="button" className="btn  btn-primary">Add </button>
                                  <button onClick={cancel}type="button" className="btn  btn-secondary mx-3">Cancel</button>
            </div>
        )
    }
export default  AddService
