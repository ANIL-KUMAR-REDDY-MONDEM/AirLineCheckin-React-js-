import React,{useEffect,useState} from 'react'
import { Link, useParams ,Redirect} from 'react-router-dom';
import { useSelector } from 'react-redux';
import axios from 'axios';
import { useDispatch } from 'react-redux';
import verifyToken from './VerifyToken';
const PassengersTable = () => {
    const {id}=useParams();
     const dispatch=useDispatch();
   
     const passengers = useSelector(state => state.passengers.passengers);
     const flights = useSelector(state => state.flights.flights);
   const state=useSelector((state)=>state)
   const flightPassengers=passengers.filter(p=>p.flightId==id)
   console.log(flightPassengers)
   console.log(id)
  useEffect(()=>{
    axios.get('/passengers').then((response)=>{
        console.log(response.data)
        dispatch({type:"GET_PASSENGERS",
     payload:response.data})
    })
},[])
useEffect(()=>{
    axios.get('/flights').then((response)=>{
        console.log(response.data)
        dispatch({type:"GET_FLIGHTS",
     payload:response.data})
    })
},[])
    const deletePassenger=(id)=>{
       
      if(verifyToken(token)==="staff")
      {
          window.confirm("YOU ARE UNAUTHORISED");
          return
      }
        if(window.confirm("Are you sure You Want to Delete")){
         axios.delete(`/passengers/${id}`).then((response)=>{
             
             console.log(response.data)
             dispatch({type:"DELETE_PASSENGER",
             payload:id})
         })  
     }
    }
  
  //alert(id)
  const token=localStorage.getItem('token')
   console.log(passengers)
   if(!verifyToken(token))
 {
     return <Redirect to="/UnAuthorised"/>
 }
    return (
        <div>
             <table className="table table-bordered shadow my-5">
                  <thead className="">
                    <tr>
                        <td>Id</td>
                        <td>Flight Id</td>
                        <td>Passport Number</td>
                        <td>Name</td>
                        <td>Seat Number</td>
                        <td>Checked In</td>
                        <td>Address</td>
                        <td>DOB</td>
                        <td>Meals</td>
                        <td>Ancilary Services</td>
                        <td>Having Infants</td>
                        <td>Edit</td>
                        <td>Delete</td>
                    </tr>
                  </thead>
                  <tbody>
                        
                           {flightPassengers.map((passenger,index)=>{
                              return  (<tr key={index}>
                                 <td>{passenger.id}</td>
                                 <td>{passenger.flightId}</td>
                        <td>{passenger.passportNumber}</td>
                        <td>{passenger.name}</td>
                        <td>{passenger.seatNumber}</td>
                        <td>{passenger.checkedIn}</td>
                        <td>{passenger.address}</td>
                        <td>{passenger.DOB}</td>
                       
                        <td>{passenger.meals}</td>
                        <td>{passenger.ancilaryServices}</td>
                        <td>{passenger.havingInfants}</td>
                        
                                            
                                           
                                             <td>
                                                 <Link to={`/editPassenger/${passenger.id}`} className="btn btn-md btn-primary"><i class="fas fa-user-edit"></i>Edit</Link>
                                             </td>
                                             <td>
                                                 <button onClick={()=>deletePassenger(passenger.id)} className="btn btn-md btn-danger"><i class="fas fa-trash-alt"></i>Delete</button>
                                             </td>
                                      </tr>
                              )
                              })}
                       
                  </tbody>
              </table>
        </div>
    )
}

export default PassengersTable
