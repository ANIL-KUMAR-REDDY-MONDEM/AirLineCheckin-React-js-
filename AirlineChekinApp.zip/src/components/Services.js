import axios from 'axios'
import React,{useEffect} from 'react'
import {useSelector, useDispatch} from 'react-redux'
import {Link,Redirect, useParams} from 'react-router-dom'
import verifyToken from './VerifyToken'

const Services = () => {
    const dispatch = useDispatch() 
  const services=useSelector((state)=>state.services.services);
  const meals=useSelector((state)=>state.meals.meals);
  const state=useSelector((state)=>state);
  console.log(state)
  console.log(services)
  const user=useSelector((state)=>state.user.user);
 
  // const {id}=useParams()
   
        useEffect(()=>{
            axios.get("/services").then((response)=>{
                dispatch({type:"GET_SERVICES",
                payload:[...response.data]})
            })         
        } ,[])
       useEffect(() => {
        axios.get("/meals").then((response)=>{
            dispatch({type:"GET_ALLMEALS",
            payload:[...response.data]})
        })
       }, [])
 const deleteMeals=(id)=>{
     //alert(id)
     if(window.confirm("Are you sure You Want to Delete")){
     axios.delete(`/meals/${id}`).then((response)=>{
         dispatch({type:"DELETE_MEALS",
        payload:id})
     })
     window.location.reload();
    }
    }



     const deleteService=(id)=>{  
        if(window.confirm("Are you sure You Want to Delete")){
       //  alert(id)
        axios.delete(`/services/${id}`).then((response)=>{
            dispatch({type:"DELETE_SERVICE",
           payload:id})
        })
        window.location.reload();
      }
    }
 const token=localStorage.getItem('token');
 const auth=verifyToken(token)
 if(auth==="staff" || auth===false)
 {
     return <Redirect to="/UnAuthorised"/>
 }
    return (
        <div>
            
            <Link to={`/admin/services/AddService`} className="btn btn-success my-5">AddService</Link>
            <table className="table table-bordered shadow my-5">
                  <thead className="">
                    <tr>
                        <td>Id</td>
                        <td>Services</td>
                        <td>Edit</td>
                        <td>Delete</td>
                    </tr>
                  </thead>
                  <tbody>
                        
                           {services.map((service,index)=>{
                              return  (<tr key={index}>
                                  <td>{service.id}</td>
                                             <td>{service.service}</td>
                                            
                                           
                                             <td>
                                                 <Link to={`/admin/services/EditService/${service.id}`} className="btn btn-md btn-primary"><i class="fas fa-user-edit"></i>Edit</Link>
                                             </td>
                                             <td>
                                                 <button onClick={()=> deleteService(service.id)} className="btn btn-md btn-danger"><i class="fas fa-trash-alt"></i>Delete</button>
                                             </td>
                                      </tr>)
                           })}
                       
                  </tbody>
              </table>



              <Link to="/admin/services/addmeals" className="btn btn-success my-5">AddMeals</Link>
            <table className="table table-bordered shadow my-5">
                  <thead className="">
                    <tr>
                    <td>Id</td>
                        <td>Meals</td>
                        <td>Edit</td>
                        <td>Delete</td>
                    </tr>
                  </thead>
                  <tbody>
                        
                           {meals.map((meal,index)=>{
                              return  (<tr key={index}>
                                             <td>{meal.id}</td>
                                            
                                             <td>{meal.dish}</td>
                                             <td>
                                                 <Link to={`/admin/services/editMeals/${meal.id}`} className="btn btn-md btn-primary"><i class="fas fa-user-edit"></i>Edit</Link>
                                             </td>
                                             <td>
                                                 <button onClick={()=>deleteMeals(meal.id)} className="btn btn-md btn-danger"><i class="fas fa-trash-alt"></i>Delete</button>
                                             </td>
                                      </tr>)
                           })}
                       
                  </tbody>
              </table>
        </div>
    )

                        }
export default Services
