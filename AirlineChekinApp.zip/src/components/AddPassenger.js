import React ,{useState,useEffect} from 'react'

import { useHistory } from 'react-router';
import {Redirect} from 'react-router-dom'
import axios from 'axios';
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux'
import verifyToken from './VerifyToken';
const  AddPassenger=()=>  {
    const dispatch=useDispatch();
    const meal=useSelector((state=>state.meals.meals))
    const flights=useSelector((state=>state.flights.flights))
    const services=useSelector((state=>state.services.services))
    const user=useSelector((state=>state.user.user))
   const [passportNumber,setPassportNumber]=useState("");
   const [name,setName]=useState("");
   const [flightId,setFlightId]=useState("");
   const [seatNumber,setSeatNumber]=useState("");
   const [checkedIn,setCheckedIn]=useState("");
   const [address,setAddress]=useState("");
   const [DOB,setDOB]=useState();
   const [meals,setMeals]=useState("");
   const [ancilaryServices,setAncilaryServices]=useState("");
   const [havingInfants,setHavingInfants]=useState("");
   const [requireWheelChair,setRequireWheelChair]=useState();
   const histroy=useHistory(); 
   function randomIntFromInterval(min, max) { // min and max included 
    return Math.floor(Math.random() * (max - min + 1) + min)
  }
  
 // const rndInt = randomIntFromInterval(1, 6)
   useEffect(()=>{
    axios.get(`/meals`).then((response)=>{
        dispatch({type:"GET_ALLMEALS",
        payload:response.data})
    })
},[])
useEffect(()=>{
    axios.get(`/flights`).then((response)=>{
        dispatch({type:"GET_FLIGHTS",
        payload:response.data})
    })
},[])
useEffect(()=>{
    axios.get(`/services`).then((response)=>{
        dispatch({type:"GET_SERVICES",
        payload:response.data})
    })
},[])
   const addPassenger=(e)=>{
             e.preventDefault();
             let data={
                 id:randomIntFromInterval(1, 200),
                 passportNumber,
                 flightId:parseInt(flightId),
                 name,
                 seatNumber,checkedIn,
                 address,
                 DOB,
                 requireWheelChair,
                 meals,
                 ancilaryServices,
                 havingInfants
             }
          
           console.log(data)
         //  if(passportNumber!=="" && name!=="" && seatNumber!=="" && address!=="" && DOB!=="" && meals!==""&&
         //  ancilaryServices!=="")
           { 
               //alert("dispatching Action")
               axios.post('/passengers',data).then((response)=>{
                dispatch({type:"ADD_PASSENGER",
                payload:response.data})
                })
                histroy.push("/admin")
            }}
const token=localStorage.getItem('token');
const auth=verifyToken(token)
if(auth==="staff" || auth===false)
{
    return <Redirect to="/UnAuthorised"/>
}
    return (
       
        <div className="container">
            
            <div className="row">
                <h1 className="display-3 text-center">
                   Adding Passenger  
                </h1>
                <div className="col-md-6 my-5 shadow mx-auto">
                         <form >
                                  <div className="form-group">
                                      <input type="text" 
                                      placeholder="Passport Number" 
                                      className="form-control"
                                      value={passportNumber}
                                      onChange={e=>setPassportNumber(e.target.value)}/>
                                  </div>
                                  <div className="form-group">
                                      <input type="text" 
                                      placeholder="Full Name" 
                                      className="form-control"
                                      value={name}
                                      onChange={e=>setName(e.target.value)}/>
                                  </div>
                                  <select value={flightId} 
                                      onChange={e=>setFlightId(e.target.value)} 
                                    
                                      className="form-select form-select-md my-3" aria-label=".form-select-lg example">
                                            <option selected>Select Flight</option>
                                            {flights.map((flight)=>(
                                            
                                            <option value={flight.id}>{flight.flightName}</option>
                                           
                                            ))}
                                           </select>
                                  <div className="form-group">
                                      <input type="text" 
                                      placeholder="Seat Number" 
                                      className="form-control"
                                      value={seatNumber}
                                      onChange={e=>setSeatNumber(e.target.value)}/>
                                  </div>
                                  <select value={checkedIn} 
                                  onChange={e=>setCheckedIn(e.target.value)} 
                                  className="form-select form-select-md " aria-label=".form-select-lg example">
                                     <option selected >Checked In</option>
                                        <option value="NO">NO</option>
                                       <option value="YES">YES</option>
 
                                       </select>
                                <select value={requireWheelChair} 
                                  onChange={e=>setRequireWheelChair(e.target.value)} 
                                  className="form-select form-select-md " aria-label=".form-select-lg example">
                                     <option selected >Require Wheel Chair</option>
                                        <option value="NO">NO</option>
                                       <option value="YES">YES</option>
 
                                       </select>
                                  <select value={meals}
                                      onChange={e=>setMeals(e.target.value)} 
                                    
                                      className="form-select form-select-md my-3" aria-label=".form-select-lg example">
                                            <option selected>No Meals</option>
                                            {meal.map((meal)=>(
                                            
                                            <option value={meal.dish}>{meal.dish}</option>
                                           
                                            ))}
                                           </select>
                                  <div className="form-group">
                                      <input type="text" 
                                      placeholder="Address" 
                                      className="form-control"
                                      value={address}
                                      onChange={e=>setAddress(e.target.value)}/>
                                  </div>
                                  <div className="form-group">
                                      <input type="date" 
                                      placeholder="Date Of Birth" 
                                      className="form-control"
                                      value={DOB}
                                      onChange={e=>setDOB(e.target.value)}/>
                                  </div>
                                  <select value={ancilaryServices}
                                      onChange={e=>setAncilaryServices(e.target.value)} 
                                    
                                      className="form-select form-select-md my-3" aria-label=".form-select-lg example">
                                            <option selected>Ancilary Services</option>
                                            {services.map((service)=>(
                                            
                                            <option value={service.service}>{service.service}</option>
                                           
                                            ))}
                                           </select>
                                  
                                  <select value={havingInfants} 
                                  onChange={e=>setHavingInfants(e.target.value)} 
                                  className="form-select form-select-md " aria-label=".form-select-lg example">
                                     <option selected >Having Infants</option>
                                        <option value="NO">NO</option>
                                       <option value="YES">YES</option>
 
                                       </select>
                                  <div className="form-group">
                                      <input type="submit" 
                                      placeholder="Submit" 
                                      className="btn btn-primary btn-block my-3"
                                      onClick={addPassenger}/>
                                  </div>
                         </form>

                </div>
            </div>
            
        </div>
    )
}

export default AddPassenger
