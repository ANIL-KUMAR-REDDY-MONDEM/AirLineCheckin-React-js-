import React,{useState,useEffect} from 'react'
import { useHistory } from 'react-router';
import { useDispatch } from 'react-redux';
import { Redirect } from 'react-router';
import axios from 'axios'
import { useSelector } from 'react-redux';
import { connect } from 'react-redux';
import { useParams } from 'react-router-dom';
import verifyToken from './VerifyToken';
const EditMeals = () => {
    const {id}=useParams();
    const dispatch=useDispatch();
    const state=useSelector((state)=>state);
    const meal=useSelector((state)=>state.meal.meal);
    console.log(meal);
    console.log(state);
     const histroy=useHistory();
     const [dish,setMeals]=useState("")
     const [redirect,setRedirect]=useState(false);
    // const meal=mealData.mealData
     const editMeals=()=>{
         // console.log(id)
          //alert(id)
              axios.put(`/meals/${id}`,{dish}).then((response)=>{
                        dispatch({type:"EDIT_MEALS",
                          payload:response.data})
                          setRedirect(true);
                        })
      }
 
 useEffect(() => {
    axios.get(`/meals/${id}`).then((response)=>{
        dispatch({type:"GET_MEAL",
          payload:response.data})
         
        })
    
 }, [])
  console.log(meal)
 
  useEffect(() => {
    if(meal!==null)
    {
        setMeals(meal.dish)
    }
  }, [meal])
 
  
      const cancel=()=>{
        
         setRedirect(true);
      }
      const token=localStorage.getItem('token');
      const auth=verifyToken(token)
      if(auth==="staff" || auth===false)
      {
          return <Redirect to="/UnAuthorised"/>
      }
      


    return (
        <div>
            <div className="container">
                  {redirect? <Redirect to="/admin/services"/>:null}
                <div className="form-group my-5">
                                      <input type="text" 
                                      placeholder="Edit Meals" 
                                      className="form-control"
                                      value={dish}
                                      onChange={e=>setMeals(e.target.value)}/>
                                  </div>
                                  <button onClick={()=>editMeals()} type="button" className="btn  btn-primary">Add </button>
                                  <button onClick={()=>cancel()}type="button" className="btn  btn-secondary mx-3">Cancel</button>
            </div>
        </div>
    )
}
const mapStateToProps=(state)=>{
    return{
        mealData:state.meal.meal
    }
}
export default EditMeals
//export default connect(mapStateToProps)(EditMeals)
