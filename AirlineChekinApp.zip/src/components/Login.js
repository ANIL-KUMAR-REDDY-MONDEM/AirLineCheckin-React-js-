import React, { useState } from 'react';
import {useHistory ,Redirect} from 'react-router-dom';
import '../stylesheets/Login.scss';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux'
import { useDispatch } from 'react-redux'
import axios from 'axios';import { connect } from 'react-redux';
import verifyToken from './VerifyToken'
//var jwt = require('jsonwebtoken');
import jwt from 'jsonwebtoken'
const Login = () => {

  const [Email, setEmail] = useState("");
  const [Password, setPassword] = useState("");
  const loginUser = useSelector((state) => state.user.user);
   const dispatch = useDispatch()
   let histroy = useHistory();
 function submitForm(e){
   e.preventDefault();
   if(Email==="" || Password==="")
   {
     alert("Pleae Fill Credentials")
     return;
   }
   else
   {
     axios.get('/users').then((response)=>{
       let user=response.data.find(u=>u.email===Email && u.password===Password);
       console.log(user)
       if(user!==undefined)
       {
         const token= jwt.sign( {data:{Email:user.email,Designation:user.designation}}, 'password', { expiresIn: '1h' });
         //alert(token)
        
         if(verifyToken(token))
         {
          // alert("inside Verify token")
           dispatch({type:'LOGIN',
          payload:user})
          localStorage.setItem('token',token);
           histroy.push('/admin');
         }
         

       }
       else{
         alert("InValid Credentials")
         return;
       }


     })
   }
 }


  return (
    
    <div className="container">
     
      <div className="row">
        <h2 className="display-1 my-5  text-center">
          login
        </h2>
        <div className="col-md-7 shadow mx-auto p-5">

          <form className="loginform">
            <h2>Airline Checkin</h2>
            <div className="col-md-7 form-group">
              <input type="email" name="username" placeholder="Enter Your Email"
                value={Email}
                onChange={e => setEmail(e.target.value)} className="form-control" />
            </div>

            <div className="col-md-7 form-group">
              <input type="password" name="password" placeholder="Enter Your password"
                value={Password}
                onChange={e => setPassword(e.target.value)} className="form-control" />
            </div>

            <button type="submit" onClick={submitForm} className="btn btn-primary mx-5">Login</button>
            <Link className="signup" to="/Signup" className="btn btn-info my-3">Signup</Link>

          </form>
        </div>
      </div>

    </div>
  )
}


export default Login
