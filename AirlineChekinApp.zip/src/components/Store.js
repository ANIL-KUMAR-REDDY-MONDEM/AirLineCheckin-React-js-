//import thunk from 'redux-thunk'

//import { composeWithDevTools } from 'redux-devtools-extension';
import {createStore} from 'redux'
//import { compressToEncodedURIComponent } from 'lz-string';
import reducers from './rootReduces';
 const store=createStore(reducers,{},window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__());
 export default store;