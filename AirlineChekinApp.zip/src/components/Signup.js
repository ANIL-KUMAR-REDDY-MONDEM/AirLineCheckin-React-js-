import React, { useState } from 'react'
import '../stylesheets/Signup.scss'
import axios from 'axios'
//import { Redirect } from 'react-router-dom';
import { useHistory } from 'react-router'
 const Signup=()=> {
     const histroy=useHistory();
   const [username,setUserName]=useState("");
   const [email,setEmail]=useState("");
   const [password,setPassword]=useState("");
   const [designation,setDesignation]=useState("");
   const [confirmPassword,setConfirmPassword]=useState("");

  
    const submitForm=(e)=>{
        e.preventDefault();
        const data={username,email,password,designation};
       if(password===confirmPassword && username!=="" && password!=="" && designation!=="" && email!=="")
       {
           axios.get('/users').then((response)=>{
               let user=response.data.find(u=>u.email===email)
               if(user!==undefined)
               {
                   alert("Email ID Already Exists");
                   return;
               }
               else{
                axios.post('/users',data).then((response)=>{
                    console.log(response)
                    if(response.status===201){
                        alert("Registered Succesfully")
                       histroy.push('/login')
                    }
                    else

                    {
                        alert("Somethig Went Wrong Try Again");
                    }
           })
               }
           })
          
          
       }
       else{
           alert("Please Fill details");
           return;
       }
    }
   
        return (
            <div className="container">
            <div className="row">
                <h1 className="display-3 text-center">
                  Sign Up
                </h1>
                <div className="col-md-6 pt-3 shadow mx-auto">
                         <form>
                                  <div className="form-group">
                                      <input type="text" 
                                      placeholder="Name" 
                                      className="form-control"
                                      value={username}
                                      onChange={e=>setUserName(e.target.value)}/>
                                  </div>
                                  <div className="form-group">
                                      <input type="text" 
                                      placeholder="Email Id" 
                                      className="form-control"
                                      value={email}
                                      onChange={e=>setEmail(e.target.value)}/>
                                  </div>
                                  <select  value={designation} 
                                  onChange={e=>setDesignation(e.target.value)} 
                                  className="form-select form-select-md " aria-label=".form-select-lg example">
                                     <option selected >Designation</option>
                                        <option value="admin">ADMIN</option>
                                       <option value="staff">STAFF</option>
 
                                       </select>
                                  
                                  <div className="form-group my-3">
                                      <input type="password" 
                                      placeholder="Password" 
                                      className="form-control"
                                      value={password}
                                      onChange={e=>setPassword(e.target.value)}/>
                                  </div>
                                  <div className="form-group">
                                      <input type="password" 
                                      placeholder="Conform Password" 
                                      className="form-control"
                                      value={confirmPassword}
                                      onChange={e=>setConfirmPassword(e.target.value)}/>
                                  </div>
                                  <div className="form-group">
                                      <input type="submit" 
                                      placeholder="Submit" 
                                      className="btn btn-primary btn-block"
                                      onClick={submitForm}/>
                                  </div>
                         </form>

                </div>
            </div>
            
        </div>
           

        )
    }

export default Signup