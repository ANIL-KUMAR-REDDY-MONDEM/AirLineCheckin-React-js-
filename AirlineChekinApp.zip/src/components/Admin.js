import React from 'react'
import '../stylesheets/Admin.scss'
import {Link,NavLink, useHistory,Redirect} from 'react-router-dom'
//import axios from 'axios';

import {useSelector} from 'react-redux'
import { useDispatch } from 'react-redux'
import Flights from './Flights'
//import UnAuthorised from './UnAuthorised';
import verifyToken from './VerifyToken';
const Admin =()=> {
    //const {id}=useParams();
   const dispatch=useDispatch();
   const histroy=useHistory()
   // const passengers=useSelector((state)=>state.passengers.passengers);
   // const user=useSelector((state)=>state.user.user);
    const state=useSelector((state)=>state);
    console.log(state);

  
    const logOut=()=>{
      dispatch({type:"LOGOUT"})
      histroy.push('/logout')
    }
    const token =localStorage.getItem('token');
    if(!verifyToken(token))
    {
        return <Redirect to="/Login" />
    }
     
        return (
            <div>
             
                <nav className="navbar  fixed-top navbar-expand-sm navbar-dark bg-dark">
                      <NavLink className="nav-link disabled" to="/home">Home</NavLink>
                      <NavLink className="nav-link disabled" to="/aboutus">AboutUs</NavLink>
                      <NavLink className="nav-link disabled" to="/privacyPolicy">Privacy Policy</NavLink>
                      <NavLink className="nav-link" to="/admin/services">Services</NavLink>
                     
                     
                     
                      <ul className="navbar-nav ml-auto">
                      <li classNam="nav-item">
                          <Link  to={`/addPassenger`} className="btn btn-small mx-2 btn-primary">AddPassenger</Link>
                          </li>
                          <li classNam="nav-item">
                          <Link to="/admin/getpassengers" className="btn btn-block mr-2 btn-primary">Get Passengers</Link>
                          </li>
                          <li className="nav-item">
                             
                          </li>
                           <li className="nav-item">
                                    <button onClick={logOut} type= "button" className="btn btn-small mx-2 btn-secondary">Logout</button>
                             </li>           
                     </ul>
                </nav>
              <Flights/>
         
            </div>
        )
    }

/*
function mapStateToProps(state){
    return{
        passengers:this.state.passengers
    }
}

export default connect(mapStateToProps)(Admin)
*/
export default Admin