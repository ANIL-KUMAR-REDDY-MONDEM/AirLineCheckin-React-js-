
//var jwt = require('jsonwebtoken');
import jwt from 'jsonwebtoken'
function verifyToken(token){
    return  jwt.verify(token, 'password', (err, decode) => decode !== undefined ? decode.data.Designation==="admin"?"admin":"staff" :false)
  }
  export default verifyToken