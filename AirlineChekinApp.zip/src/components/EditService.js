import axios from 'axios'
import React, { useState ,useEffect} from 'react'
import { Link, Redirect } from 'react-router-dom'
import { useDispatch } from 'react-redux'
//import { useHistory } from 'react-router'
import { useParams } from 'react-router-dom'
import { useSelector } from 'react-redux'
import verifyToken from './VerifyToken'
const EditService = () => {
    const {id}=useParams();
    const dispatch=useDispatch();
    const state=useSelector((state)=>state);
    const serviceData=useSelector((state)=>state.service.service);
   // console.log(serviceData);
   // console.log(state);
     //const histroy=useHistory();
     const [service,setService]=useState("")
     const [redirect,setRedirect]=useState(false);
    // const meal=mealData.mealData
     const editService=()=>{
         // console.log(id)
         // alert(id)
              axios.put(`/services/${id}`,{service}).then((response)=>{
                        dispatch({type:"UPDATE_SERVICE",
                          payload:response.data})
                          setRedirect(true);
                        })
      }
 
 useEffect(() => {
    axios.get(`/services/${id}`).then((response)=>{
        dispatch({type:"GET_SERVICE",
          payload:response.data})
         
        })
    
 }, [])
 // console.log(service)
 
  useEffect(() => {
    if(serviceData!==undefined && serviceData!==null)
    {
        setService(serviceData.service)
    }
  }, [serviceData])
 
  
      const cancel=()=>{
        
         setRedirect(true);
      }
  
const token=localStorage.getItem('token');
const auth=verifyToken(token)
if(auth==="staff" || auth===false)
{
    return <Redirect to="/UnAuthorised"/>
}


    return (
        <div>
            <div className="container">
                  {redirect? <Redirect to="/admin/services"/>:null}
                <div className="form-group my-5">
                                      <input type="text" 
                                      placeholder="Edit Service" 
                                      className="form-control"
                                      value={service}
                                      onChange={e=>setService(e.target.value)}/>
                                  </div>
                                  <button onClick={()=>editService()} type="button" className="btn  btn-primary">Add </button>
                                  <button onClick={()=>cancel()}type="button" className="btn  btn-secondary mx-3">Cancel</button>
            </div>
        </div>
    )
}

export default EditService
