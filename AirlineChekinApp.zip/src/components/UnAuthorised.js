import React from 'react'
import { Link } from 'react-router-dom'
const UnAuthorised = () => {
    return (
        <div className="container">
         <div className="row">
         <h1 className="display-3 text-center">
                  You are UnAuthorised
        </h1>
        <Link style={{width:"5em",marginLeft:"30em"}}className="btn btn-dark"to="/Login">Login</Link>
         </div>
        </div>
    )
}

export default UnAuthorised
