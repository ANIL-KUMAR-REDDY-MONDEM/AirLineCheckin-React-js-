
 const initialPassengers={
   passengers:[]
 }
  

export const passengerReducer = (state=initialPassengers,{type,payload}) => {
   switch (type) {
      
          
    case "ADD_PASSENGER":
        console.log(payload)
       
        return{ ...state,
            passengers:[payload,...state.passengers]
        }
      case "UPDATE_PASSENGER":
        console.log(payload)
        const updatedstate=state.passengers.map(p=>p.id===payload.id?payload:p)
       
       console.log(updatedstate)
        return {
          ...state,passengers:updatedstate
        };

      case "GET_PASSENGERS":
          
         console.log({ ...state,
          passengers:payload
          })
           return{ ...state,
           passengers:payload
           }
      case "DELETE_PASSENGER":
      console.log(payload)
      console.log(state.passengers.filter((p)=> p.id!==payload))
        return {...state,passengers:state.passengers.filter((p)=>p.id!==payload)}

       default:
        return{
            ...state  
        }
   }
}



const initialPassenger = {
  passenger:{}

}

export const onePassengerReducer= (state = initialPassenger, { type, payload }) => {
  switch (type) {

  case "GET_PASSENGER":
    console.log(payload)
    return { ...state, passenger:payload}

  default:
    return state
  }
}


const initialUser = {
         user:{}
}

export const loginReducer= (state = initialUser, { type, payload }) => {
  switch (type) {

  case "LOGIN":
    //alert("inside login reducer")
    return { ...state, user:payload }
case "LOGOUT":
  localStorage.setItem('token',null)
  return{
    ...state,user:{}
  }
  default:
    return state
  }
}

const oneServiceReducer={
  service:{}
}
export const serviceReducer=(state=oneServiceReducer,{type,payload})=>{
  switch(type){
    case "GET_SERVICE":
      return{
        ...state,service:payload
      }
      default:
    return state
  }
}
const initialServices = {
  services:[]
}



export const servicesReducer= (state = initialServices, { type, payload }) => {
  switch (type) {

  case "GET_SERVICES":
    //alert("reached reducer")
    return { ...state, services:payload }


    case "UPDATE_SERVICE":
     alert(payload.id)
        console.log(payload)
        const updatedstate=state.services.map(p=>p.id===payload.id?payload:p)
       
       console.log(updatedstate)
        return {
          ...state,services:updatedstate
        };


      case "DELETE_SERVICE":
        alert(payload)
        return { ...state, services: state.services.filter((p)=>p.id!==payload)} 

  default:
    return state
  }
}


const initialFlights = {
       flights:[]
}

export const flightsReducer= (state = initialFlights, { type, payload }) => {
  switch (type) {

  case "GET_FLIGHTS":
    return { ...state, flights:[...payload] }
    case "UPDATE_FLIGHTS":
     
        console.log(payload)
        const updatedstate=state.flights.map(p=>p.id===payload.id?payload:p)
       
       console.log(updatedstate)
        return {
          ...state,flights:updatedstate
        };
case "DELETE_FLIGHT":
  alert("DELETE_FLIGHT Reducer")
  const afterDeleteState=state.flights.map(p=>p.id!==payload.id?payload:p)
       
  console.log( afterDeleteState)
   return {
     ...state,flights: afterDeleteState
   };
  default:
    return state
  }
}


const initialMeals = {
      meals:[]
}

export const mealsReducer=(state = initialMeals, { type, payload }) => {
  switch (type) {

  case "GET_ALLMEALS":
    return { ...state, meals:[...payload] }
case "EDIT_MEALS":

        console.log(payload)
        const updatedstate=state.meals.map(p=>p.id===payload.id?payload:p)
       
       console.log(updatedstate)
        return {
          ...state,meals:updatedstate
        };
  default:
    return state
  }
}



const oneInitialMeals = {
  meal:{}
}
export const mealReducer=(state = oneInitialMeals, { type, payload }) => {
  switch (type) {

  case "GET_MEAL":
    return { ...state, meal:payload }

  default:
    return state
  }
}