import axios from 'axios'
import React,{useState,useEffect} from 'react'
import {useSelector} from 'react-redux'
import '../stylesheets/passengers.scss'
import { useDispatch } from 'react-redux'
import { useParams,Redirect } from 'react-router-dom'
import verifyToken from './VerifyToken'
const GetPasengers = () => {
   // const {id}=useParams();
    const changeStatus=(id)=>{
        axios.get(`/passengers/${id}`).then((response)=>{
            let data=response.data
            console.log(data)
            data.checkedIn=data.checkedIn==="YES"?"NO":"YES"
            console.log(data)
            axios.put(`/passengers/${id}`,data).then((response)=>{
                console.log(response.data)
                dispatch({type:"UPDATE_PASSENGER",payload:data})
            })
        })
       
    }
   const dispatch = useDispatch()
    const passengers=useSelector((state)=>state.passengers.passengers)
    const flights=useSelector((state)=>state.flights.flights)
    const state=useSelector((state)=>state)
    console.log(state)
    useEffect(()=>{
        let mounted=true;
              axios.get('/passengers').then((response)=>{
                       dispatch({type:"GET_PASSENGERS",
                    payload:response.data})
              })
              return ()=> mounted=false;
    },[])
const token=localStorage.getItem('token');
 if(!verifyToken(token))
 {
     return <Redirect to="/UnAuthorised"/>
 }
    return (
        <>
        {flights.map((flight)=>(
           
           <>
       <div className="well">
            <div id="box">
                  <span className="mx-3" style={{  fontWeight:"500", fontSize:"25px",fontFamily:"Arial"}}>Flight Name : {flight.flightName}</span><br/>
                  <span className="mx-3"  style={{ fontWeight:"500", fontSize:"20px",fontFamily:"Arial"}}>Time : {flight.time}</span><br/>
                   <span className="mx-3" style={{ fontWeight:"500", fontSize:"20px",fontFamily:"Arial"}}>Pilot : {flight.pilot}</span><br/>
                </div>               
        </div>
        <div className="well">
            <div id="box">
                   {passengers.map((passenger,index)=>(
                        <>
                            {passenger.flightId===flight.id?                                   
                                 passenger.checkedIn==="YES"?  
                                  <>

                                                          
                                    <button 
                                     style={{backgroundColor:"blue"}}                                
                                     onClick={()=>changeStatus(passenger.id)}
                                      type="checkbox" 
                                      id="passenger">{/*  {passenger.havingInfants==="YES"?<i className="fa-solid fa-baby-carriage fa-pull-top"  style={{color:"black"}}></i>:null}*/}
                                      {passenger.seatNumber} 
                                      {passenger.requireWheelChair==="YES"?<i className="fas fa-wheelchair"></i>:null}</button>
                                 
                                     </>

                                  :
                                   <>
                                       
                                      <button 
                                      style={{color:"gray"}}
                                     
                                       onClick={()=>changeStatus(passenger.id)}
                                        type="checkbox" 
                                        id="passenger"> {/*   {passenger.havingInfants==="YES"?<i className="fas fa-baby"></i>:null}*/}
                                            {passenger.seatNumber} 
                                        {passenger.requireWheelChair==="YES"?<i className="fas fa-wheelchair ml-5"></i>:null}</button>  
                                    </>                                
                                :null}
                                </>
                                ))}
            </div>
        </div>
        </>
 ))}
        </>
                                
    )
}

export default GetPasengers
