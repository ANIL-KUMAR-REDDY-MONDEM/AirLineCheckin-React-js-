import { combineReducers } from "redux";
import {loginReducer, 
    passengerReducer,
    flightsReducer,
    servicesReducer,
    mealsReducer, 
    onePassengerReducer,
    serviceReducer,
    mealReducer} from './Reducers'
const reducers=combineReducers({
    passengers:passengerReducer,
    user:loginReducer,
    flights:flightsReducer,
    services:servicesReducer,
    meals:mealsReducer,
    passenger: onePassengerReducer,
    meal:mealReducer,
    service:serviceReducer
})
export default reducers