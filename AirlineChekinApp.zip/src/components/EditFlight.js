import axios from 'axios';
import React,{useState,useEffect} from 'react'
import { useParams } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { useDispatch } from 'react-redux';

const EditFlight = () => {
    const flight = useSelector(state => state.flight.flight);
    const dispatch=useDispatch();
    const [flightName, setFlightName] = useState("");
    const [pilot,setPilot]=useState("");
    const [time, setTime] = useState();
    const [image,setImage]=useState("")
    const {id}=useParams();
   
    useEffect(() => {
      const response=  axios.get(`/flights/${id}`).catch((error)=>console.log(error))
      console.log(response.data);
      dispatch({type:"UPDATE_FLIGHT",
      payload:response.data})
      if(flight)
      {
          setFlightName(flight.flightName);
          setPilot(flight.pilot);
          setTime(flight.time);
          setImage(flight.img);
      }
    }, [])
    const data={flightName,pilot,time,image};
   const updateFlight=()=>{
      const response= axios.put(`/flights/${id}`,{data}).catch((error)=>console.log(error));
      console.log(response.data);
      dispatch({type:"UPDATE_FLIGHT",
       payload:response.data})
   }
    
    return (
        <div className="container">
            
        <div className="row">
            <h1 className="display-3 text-center">
              Edit Flight {id} 
            </h1>
            <div className="col-md-6 my-5 shadow mx-auto">
                     <form >
                              <div className="form-group">
                                  <input type="text" 
                                  placeholder="Flight Name" 
                                  className="form-control"
                                  value={flightName}
                                  onChange={e=>setFlightName(e.target.value)}/>
                              </div>
                              <div className="form-group">
                                  <input type="text" 
                                  placeholder="Full Name" 
                                  className="form-control"
                                  value={pilot}
                                  onChange={e=>setPilot(e.target.value)}/>
                              </div>
                              <div className="form-group">
                                  <input type="time" 
                                  placeholder="Seat Number" 
                                  className="form-control"
                                  value={time}
                                  onChange={e=>setTime(e.target.value)}/>
                              </div>
                              
                              
                              <div className="form-group">
                                  <input type="date" 
                                  placeholder="Date Of Birth" 
                                  className="form-control"
                                  value={image}
                                  onChange={e=>setImage(e.target.value)}/>
                              </div>
                             
                              
                              
                              <div className="form-group">
                                  <input type="submit" 
                                  placeholder="Submit" 
                                  className="btn btn-primary btn-block my-3"
                                  onClick={updateFlight}/>
                              </div>
                     </form>

            </div>
        </div>
        
    </div>
    )
}

export default EditFlight
