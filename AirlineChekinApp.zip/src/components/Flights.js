import React,{useEffect} from 'react'
import { useDispatch,useSelector } from 'react-redux'
import '../stylesheets/flight.scss'
import verifyToken from './VerifyToken'
import axios from 'axios'
import { useParams } from 'react-router'
import {Link, Redirect,NavLink, useHistory} from 'react-router-dom'
const Flights = () => {
const dispatch=useDispatch()
const {id}=useParams();
const flights=useSelector((state)=>state.flights.flights);
const state=useSelector((state)=>state);console.log(state);
    useEffect(()=>{
      const token=localStorage.getItem('token');
      if(!verifyToken(token)){
        alert("Invalid token")
        return
      }
        axios.get("/flights").then((response)=>{
            dispatch({type:"GET_FLIGHTS",
            payload:response.data})
        })
       
       },[])

    const deleteFlight=(id)=>{
      alert(id);
      const flight=axios.delete(`/flights/${id}`).catch((error)=>console.log(error));
      console.log(flight.data)
      dispatch({type:"DELETE_FLIGHT",
    payload:flight.data})
    }
   
    return (
       <>
{flights.map((flight)=>(
    <div  id="flight" className="card mx-5" style={{width: "18rem",float: "left"}}>
    <img className="card-img-top" src={flight.img} alt="Card image cap"/>
  <div className="card-body">
    <h5 className="card-title">{flight.flightName}</h5>
    Time : <span  style={{fontWeight:"bold"}}>{flight.time}</span><br/>
    Pilot : <span style={{fontWeight:"bold"}}>{flight.pilot}</span>
    <Link  to={`/admin/editPassengers/${flight.id}`} className="btn btn-primary mx-0">Manage Passengers</Link><br/>
    
    {/*  <Link  to="/admin/editFlight" className="btn btn-dark m-3">Edit</Link>
    <button onClick={()=>deleteFlight(flight.id)} className="btn btn-danger ">Delete</button>*/}
  </div>
</div>
))}
 
      </> 
       
    )
}

export default Flights
