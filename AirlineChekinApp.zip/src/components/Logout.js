import React, { Component } from 'react'
import {Link} from 'react-router-dom'
import '../stylesheets/Logout.scss'
export default class Logout extends Component {
	constructor(props)
	{
		super(props);
		
	}
	render() {
		return (
			<div className="loggedOut">
				<h1>you have been logged out</h1>
				<Link className="btn btn-primary" to="/">Login Again</Link>
			</div>
		)
	}
}
