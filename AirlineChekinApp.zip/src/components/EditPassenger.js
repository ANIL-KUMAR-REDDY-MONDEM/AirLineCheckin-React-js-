import axios from 'axios'
import React,{useState,useEffect} from 'react'
import {useDispatch} from 'react-redux'
import { useParams } from 'react-router-dom'
import { useHistory,Redirect } from "react-router-dom";
import { useSelector } from 'react-redux'
import { connect } from 'react-redux';
import verifyToken from './VerifyToken';
const EditPassenger = (passengerData) => {
    const {id}=useParams();
    const dispatch = useDispatch();
     const histroy=useHistory();
   // const passenger=useSelector((state)=>state.passenger.passenger);
    const meal=useSelector((state)=>state.meals.meals);
    const flights=useSelector((state)=>state.flights.flights);
    const state=useSelector((state)=>state);
    console.log(state)

    const [passportNumber,setPassportNumber]=useState("");
   const [name,setName]=useState("");
   const [flightId,setFlightId]=useState("");
   const [seatNumber,setSeatNumber]=useState("");
   const [address,setAddress]=useState("");
   const [DOB,setDOB]=useState("");
   const [checkedIn,setCheckedIn]=useState("");
   const [meals,setMeals]=useState("");
   const [ancilaryServices,setAncilaryServices]=useState("");
   const [requireWheelChair,setRequireWheelChair]=useState("");
   const [havingInfants,setHavingInfants]=useState("");
   console.log(parseInt(id));
   const data={
    passportNumber,
    name,
    flightId,
    requireWheelChair,
    seatNumber,
    address,DOB,meals,ancilaryServices,havingInfants,
    checkedIn
}

    useEffect(()=>{
       
        axios.get(`/meals`).then((response)=>{
            dispatch({type:"GET_ALLMEALS",
            payload:response.data})             
        })
        axios.get(`/passengers/${id}`).then((response)=>{
            console.log(response.data)
            dispatch({type:"GET_PASSENGER",
            payload:response.data})
        })
        axios.get(`/flights`).then((response)=>{
            dispatch({type:"GET_FLIGHTS",
            payload:response.data})             
        })
       
    },[])

    useEffect(()=>{
        if(passengerData!==undefined && passengerData!==null)
        { 
        // alert(passengerData.passportNumber)
        let Data=passengerData.passengerData
                setPassportNumber(Data.passportNumber);
                setName(Data.name);
                setAddress(Data.address)
                setFlightId(Data.flightId)
                setDOB(Data.DOB)
                setCheckedIn(Data.checkedIn)
                setSeatNumber(Data.seatNumber);
                setRequireWheelChair(Data.requireWheelChair);
                setMeals(Data.meals);
                setAncilaryServices(Data.ancilaryServices)
                setHavingInfants(Data.havingInfants);
         }
    },[passengerData])
    

console.log(passengerData.passengerData)
    console.log(state)
   

const save=(e)=>{
         e.preventDefault();
         axios.put(`/passengers/${id}`,data).then((response)=>{
         console.log(response.data)
         dispatch({type:"UPDATE_PASSENGER",payload:response.data})
                 })  
                 
                 histroy.push('/admin')
         }
const token=localStorage.getItem('token');
 if(!verifyToken(token))
 {
     return <Redirect to="/UnAuthorised"/>
 }
    return (
        <div className="container">
            <div className="row">
                <h1 className="display-3 text-center">
                  Edit Passenger  {id}
                </h1>
                <div className="col-md-6 my-5 shadow mx-auto">
                         <form >
                                  <div className="form-group">
                                      <input type="text" 
                                      placeholder="Passport Number" 
                                      className="form-control"
                                      value={passportNumber}
                                      onChange={e=>setPassportNumber(e.target.value)}/>
                                  </div>
                                  <div className="form-group">
                                      <input type="text" 
                                      placeholder="Full Name" 
                                      className="form-control"
                                      value={name}
                                      onChange={e=>setName(e.target.value)}/>
                                  </div>
                                  <select value={flightId} 
                                      onChange={e=>setFlightId(e.target.value)} 
                                    
                                      className="form-select form-select-md my-3" aria-label=".form-select-lg example">
                                            <option selected>Select Flight</option>
                                            {flights.map((flight)=>(
                                            
                                            <option value={flight.id}>{flight.flightName}</option>
                                           
                                            ))}
                                           </select>
                                  <select value={checkedIn} 
                                  onChange={e=>setCheckedIn(e.target.value)} 
                                  className="form-select form-select-md my-3" aria-label=".form-select-lg example">
                                     <option selected disabled>Checked In</option>
                                        <option value="NO">NO</option>
                                       <option value="YES">YES</option>
 
                                       </select>
                                       <select value={requireWheelChair} 
                                  onChange={e=>setRequireWheelChair(e.target.value)} 
                                  className="form-select form-select-md " aria-label=".form-select-lg example">
                                     <option selected >Require Wheel Chair</option>
                                        <option value="NO">NO</option>
                                       <option value="YES">YES</option>
 
                                       </select>
                                  <div className="form-group my">
                                      <input type="text" 
                                      placeholder="Seat Number" 
                                      className="form-control"
                                      value={seatNumber}
                                      onChange={e=>setSeatNumber(e.target.value)}/>
                                  </div>
                                  <div className="form-group">
                                      <input type="text" 
                                      placeholder="Address" 
                                      className="form-control"
                                      value={address}
                                      onChange={e=>setAddress(e.target.value)}/>
                                  </div>
                                  <div className="form-group">
                                      <input type="date" 
                                      placeholder="Date Of Birth" 
                                      className="form-control"
                                      value={DOB}
                                      onChange={e=>setDOB(e.target.value)}/>
                                  </div>
                                  <div className="form-group">
                                      <input type="text" 
                                      placeholder="AncilaryServices" 
                                      className="form-control"
                                      value={ancilaryServices}
                                      onChange={e=>setAncilaryServices(e.target.value)}/>
                                  </div>
                                
                                      <select value={meals} 
                                      onChange={e=>setMeals(e.target.value)} 
                                    
                                      className="form-select form-select-md my-3" aria-label=".form-select-lg example">
                                            <option selected>No Meals</option>
                                            {meal.map((meal)=>(
                                            
                                            <option value={meal.dish}>{meal.dish}</option>
                                           
                                            ))}
                                           </select>
                                 
                                  <select value={havingInfants} 
                                  onChange={e=>setHavingInfants(e.target.value)} 
                                  className="form-select form-select-md " aria-label=".form-select-lg example">
                                     <option value=""  disabled selected>Having Infants</option>
                                        <option value="NO">NO</option>
                                       <option value="YES">YES</option>
 
                                       </select>
                                  <div className="form-group">
                                      <input type="submit" 
                                      placeholder="Save" 
                                      className="btn btn-primary btn-block my-3"
                                      onClick={save}/>
                                  </div>
                         </form>

                </div>
            </div>
            
        </div>
    )
}
const mapStateToProps=(state)=>{
    return{
        passengerData:state.passenger.passenger
    }
 
}
export default connect(mapStateToProps)(EditPassenger)
/*if(passenger && passenger!==null)
{ 
 console.log(parseInt(id));
 console.log(passenger);
        setPassportNumber(passenger.passportNumber);
        setName(passenger.name);
        setAddress(passenger.address)
        setDOB(passenger.DOB)
        setCheckedIn(passenger.checkedIn)
        setSeatNumber(passenger.seatNumber);
        setMeals(passenger.meals);
        setAncilaryServices(passenger.ancilaryServices)
        setHavingInfants(passenger.havingInfants);
 }*/