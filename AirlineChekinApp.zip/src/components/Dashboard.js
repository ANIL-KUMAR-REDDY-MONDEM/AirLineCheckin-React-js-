import React, { Component } from 'react'
import { NavLink } from 'react-router-dom'
import '../stylesheets/Dashboard.scss'
//import '../../node_modules/bootstrap/dist/css/bootstrap.min.css'
export default class Dashboard extends Component {
    render() {
        return (
            <div>
              
                <nav className="navbar navbar-expand-lg bg-dark">
                      <NavLink className="nav-link disabled" to="/home" >Home</NavLink>


                      <ul className="navbar-nav ml-auto">
                          <li className="nav-item">
                             <NavLink className="nav-link" to='/Login' >Login</NavLink>
                          </li>
           
                         <li className="nav-item">
                              <NavLink className="nav-link" to='/signup'>Signup</NavLink>
                         </li>

                       </ul>
                </nav>
          
            </div>
        )
    }
}
