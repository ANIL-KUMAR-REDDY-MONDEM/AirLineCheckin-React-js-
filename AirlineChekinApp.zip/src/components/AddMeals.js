import React,{useState} from 'react'
import { useHistory } from 'react-router';
import { useDispatch } from 'react-redux';
import { Redirect } from 'react-router';
import axios from 'axios'
import { Link } from 'react-router-dom';
import verifyToken from './VerifyToken';
const AddMeals = () => {
    const dispatch=useDispatch();
    //  const {id}=useParams();
     const histroy=useHistory();
     const [dish,setMeals]=useState("")
     const [redirect,setRedirect]=useState(false);
     const addMeals=(e)=>{
             e.preventDefault();
              axios.post('/meals',{dish}).then((response)=>{
                        dispatch({type:"ADD_MEALS",
                          payload:response.data})
                          setRedirect(true);
                        })
      }
  
  
  
      const cancel=()=>{
        
         setRedirect(true);
      }
  
      if(redirect){
          return (
              <Redirect to="/admin/services"/>
          )
      }

      const token=localStorage.getItem('token');
      if(!verifyToken(token))
      {
          return <Redirect to="/UnAuthorised"/>
      }
    return (
        <div>
            <div className="container">
                  {redirect? <Redirect to="/admin/services"/>:null}
                <div className="form-group my-5">
                                      <input type="text" 
                                      placeholder="Add Meals" 
                                      className="form-control"
                                      value={dish}
                                      onChange={e=>setMeals(e.target.value)}/>
                                  </div>
                                  <button onClick={addMeals} type="button" className="btn  btn-primary">Add </button>
                                  <button onClick={cancel}type="button" className="btn  btn-secondary mx-3">Cancel</button>
            </div>
        </div>
    )
}

export default AddMeals
